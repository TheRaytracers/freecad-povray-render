# Templates for the inc File

If you don't have so much knowledge about POV-Ray you can use this templates to fill the _user.inc. They are like patterns, you can use they a they are, but you can also edit them and optimize them for your specific case of use.

A lot of templates, not specific for the workbench but for POV-Ray, can you find here (some of them here a also basing on them):  
[f-lohmueller -  Insert Menu Addons](http://www.f-lohmueller.de/pov_tut/addon/00_Basic_Templates/_index.htm)
